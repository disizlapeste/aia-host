<?php

/**
 * @file
 * This file is no longer in use, and only relevant for Slick 2.x.
 *
 * This file is kept to avoid potential issues when upgrading from old to the
 * new Slick by manually placing new folder on top the old one.
 * The best way to update is to remove the entire old folder, and place the new
 * one like what is done by core Update manager.
 * This shouldn't happen if you run the update via Drupal UI.
 *
 * What this file does is replacing old SlickUi.class.php with this empty one.
 *
 * @todo delete after full release or so.
 */
