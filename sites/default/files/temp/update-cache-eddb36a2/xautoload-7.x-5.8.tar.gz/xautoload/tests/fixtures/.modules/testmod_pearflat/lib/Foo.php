<?php

class testmod_pearflat_Foo {}
