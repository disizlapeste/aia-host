<div class="<?php print $classes; ?>">
	<?php if (isset($logo)): ?>
	<div class="site-logo clearfix">
		<?php print $linked_logo; ?>
	</div>
	<?php endif; ?>
	<?php print $content; ?>
</div>
