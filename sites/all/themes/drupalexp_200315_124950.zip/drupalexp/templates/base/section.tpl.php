<!--#<?php print $html_id;?>--><?php print PHP_EOL;?>
<section <?php print $attributes;?>>
	<div class="<?php print $container_class;?>">
		<div class="row">
			<?php print $content; ?>
		</div>
	</div>
</section>
<!--END #<?php print $html_id;?>--><?php print PHP_EOL;?>
