<?php
  $theme = drupalexp_get_theme();
	print $theme->pageRender(true);
?>
<!--page rendered by drupalexp drupal theme framework-->
