<?php print $page; ?>
