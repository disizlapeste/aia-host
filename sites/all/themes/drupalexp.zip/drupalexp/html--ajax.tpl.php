<?php print $page; ?>
